const mysql = require('mysql2/promise');
const { Sequelize } = require('sequelize');

module.exports = db = {};

initialize();

async function initialize() {
    // create db if it doesn't already exist
    let connection = {};
    let sequelize = {};
    if(process.env.NODE_ENV === 'production'){
        connection = await mysql.createConnection(process.env.DATABASE_URL);
        await connection.query(`CREATE DATABASE IF NOT EXISTS \`${process.env.DB_NAME}\`;`);
        // connect to db
        sequelize = new Sequelize(process.env.DATABASE_URL, { dialect: 'mysql' });

    } else {
        const host = process.env.DB_HOST;
        const port = process.env.DB_PORT;
        const user = process.env.DB_USER;
        const password = process.env.DB_PASSWORD;

        connection = await mysql.createConnection({ host, port, user, password });    
        await connection.query(`CREATE DATABASE IF NOT EXISTS \`${process.env.DB_NAME}\`;`);
        // connect to db
        sequelize = new Sequelize(process.env.DB_NAME, user, password, { dialect: 'mysql' });
    }

    // init models and add them to the exported db object
    db.User = require('../users/user.model')(sequelize);
    db.Aircraft = require('../aircrafts/aircraft.model')(sequelize);
    db.Manufacturer = require('../manufacturers/manufacturer.model')(sequelize);
    db.ModelMedia = require('../model_media/model_media.model')(sequelize);
    db.ModelScale = require('../model_scales/model_scale.model')(sequelize);
    db.AircraftGroup = require('../aircraft_groups/aircraft_group.model')(sequelize);
    db.AircraftModel = require('../aircraftmodels/aircraftmodel.model')(sequelize);
    db.AircraftImage = require('../aircraft_images/aircraft_image.model')(sequelize);

    // sync all models with database
    await sequelize.sync();

    db.sequelize = sequelize;
    db.Sequelize = Sequelize;
}