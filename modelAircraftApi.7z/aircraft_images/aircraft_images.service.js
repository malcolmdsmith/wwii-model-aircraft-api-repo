const db = require('_helpers/db');

module.exports = {
    getAll,
    getById,
    getMainImage,
    create,
    update,
    delete: _delete,
    validateAircraftImageOwner,
    getHomeImages
};

async function getAll() {
    return await db.AircraftImage.findAll();
}

async function getById(id) {
    return await getAircraftImage(id);
}

async function getMainImage(aircraft_id) {
    const image = await db.AircraftImage.findOne({ where: { aircraft_id: aircraft_id, show_main_image: true} });
    return image;
}
async function getHomeImages(imageCount) {
    return await db.AircraftImage.findAll({ limit: parseInt(imageCount)});
}

async function create(params) {
    // validate
    // if (await db.AircraftImage.findOne({ where: { aircraft_id: params.aircraft_id, show_main_image: params.show_main_image} })) {
    //     throw 'An image already exists as the main image.';
    // }

    const image = await db.AircraftImage.findOne({ where: { aircraft_id: params.aircraft_id} });
    if(image)
        await image.destroy();

    // save AircraftImage
    const result = await db.AircraftImage.create(params);
    return result;
}

async function update(id, params) {
    const aircraftImage = await getAircraftImage(id);

    // validate
    if (!aircraftImage)
        throw 'Aircraft Image with the id does not exist.'
    
    Object.assign(aircraftImage, params);
    await aircraftImage.save();

    return aircraftImage.get();
}

async function _delete(id) {
    const aircraftImage = await getAircraftImage(id);
    await aircraftImage.destroy();
}

// helper functions

async function getAircraftImage(id) {
    const aircraftImage = await db.AircraftImage.findByPk(id);
    if (!aircraftImage) throw 'Aircraft Image not found.';
    return aircraftImage;
}

async function validateAircraftImageOwner(id, user_id) {
    const aircraftImage = await db.AircraftImage.findByPk(id);
    if (!aircraftImage) throw 'Aircraft Image not found.';
    return (aircraftImage.owner_id === user_id); 
}


