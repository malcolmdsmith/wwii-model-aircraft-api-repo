const { DataTypes } = require('sequelize');

module.exports = model;

function model(sequelize) {
    const attributes = {
        image_id: { type: DataTypes.INTEGER, autoIncrement:true, primaryKey:true},
        aircraft_id: { type: DataTypes.INTEGER},
        aircraft_image: { type: DataTypes.TEXT, allowNull: false },
        show_main_image: { type: DataTypes.TINYINT, allowNull: false },
        owner_id: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 1 },
    };

    const options = {
        defaultScope: {
            // exclude hash by default
            attributes: { exclude: ['hash'] }
        },
        scopes: {
            // include hash with this scope
            withHash: { attributes: {}, }
        }
    };

    return sequelize.define('AircraftImage', attributes, options);
}